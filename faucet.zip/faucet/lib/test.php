<? 
  require_once 'jsonRPCClient.php';
 
  $bitcoin = new jsonRPCClient('http://kitteh:zomgitworks@151.227.69.160:9192/');
 
echo "<pre>\n";
print_r($bitcoin->getinfo());

print_r($bitcoin->getreceivedbyaddress('KHi1Lf6Hi81yc61r5SKQMvkCMSF5s9JbSY'));
echo "</pre>";
  
?>
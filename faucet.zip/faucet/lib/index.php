<?php
header("../");
?>